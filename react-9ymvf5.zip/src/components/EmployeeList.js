import React from 'react';

const EmployeeList = ({ employees }) => {
  return (
    <table>
      <thead>
        <tr>
          <th>ID</th>
          <th>Name</th>
          <th>Age</th>
          <th>Gender</th>
          <th>Email</th>
          <th>Phone Number</th>
        </tr>
      </thead>
      <tbody>
        {employees.map((employee) => (
          <tr key={employee.id}>
            <td>{employee.id}</td>
            <td>{employee.name}</td>
            <td>{employee.age}</td>
            <td>{employee.gender}</td>
            <td>{employee.email}</td>
            <td>{employee.phoneNo}</td>
          </tr>
        ))}
      </tbody>
    </table>
  );
};

export default EmployeeList;
