import React from 'react';
import EmployeeList from './EmployeeList';
import LogoutButton from './LogoutButton';

const Dashboard = ({ employees }) => {
  return (
    <div>
      <h2>Employee Dashboard</h2>
      <EmployeeList employees={employees} />
      <LogoutButton />
    </div>
  );
};

export default Dashboard;
