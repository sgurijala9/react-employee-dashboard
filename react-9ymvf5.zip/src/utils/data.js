export const getEmployees = () => {
  return new Promise((resolve, reject) => {
    try {
      const employees = [
        {
          id: 1,
          name: 'John Smith',
          age: 35,
          gender: 'male',
          email: 'john.smith@example.com',
          phoneNo: '555-1234',
        },
        {
          id: 2,
          name: 'Jane Doe',
          age: 27,
          gender: 'female',
          email: 'jane.doe@example.com',
          phoneNo: '555-5678',
        },
        {
          id: 3,
          name: 'Bob Johnson',
          age: 42,
          gender: 'male',
          email: 'bob.johnson@example.com',
          phoneNo: '555-9012',
        },
        {
          id: 4,
          name: 'Samantha Lee',
          age: 29,
          gender: 'female',
          email: 'samantha.lee@example.com',
          phoneNo: '555-3456',
        },
        {
          id: 5,
          name: 'David Chen',
          age: 31,
          gender: 'male',
          email: 'david.chen@example.com',
          phoneNo: '555-7890',
        },
      ];
      resolve(employees);
    } catch (error) {
      reject(error);
    }
  });
};
