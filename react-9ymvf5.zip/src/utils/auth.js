const FAKE_USER = {
  email: 'test@test.com',
  password: 'Password1!',
};

export const authenticate = (email, password) => {
  return new Promise((resolve, reject) => {
    setTimeout(() => {
      if (email === FAKE_USER.email && password === FAKE_USER.password) {
        resolve();
      } else {
        reject(new Error('Invalid email or password.'));
      }
    }, 1000);
  });
};

export const logout = () => {
  // logout logic
};
