import React, { useState, useEffect } from 'react';
import { getEmployees } from './utils/data';
import LoginForm from './components/LoginForm';
import Dashboard from './components/Dashboard';
import './style.css';

const App = () => {
  const [employees, setEmployees] = useState([]);
  const [loggedIn, setLoggedIn] = useState(false);

  useEffect(() => {
    async function fetchData() {
      const data = await getEmployees();
      setEmployees(data);
    }
    fetchData();
  }, []);

  const handleLogin = () => {
    setLoggedIn(true);
  };

  const handleLogout = () => {
    setLoggedIn(false);
  };

  return (
    <div className="app">
      {loggedIn ? (
        <Dashboard employees={employees} handleLogout={handleLogout} />
      ) : (
        <LoginForm handleLogin={handleLogin} />
      )}
    </div>
  );
};

export default App;
